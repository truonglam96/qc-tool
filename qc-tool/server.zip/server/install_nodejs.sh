sudo apt install npm
sudo npm cache clean -f
sudo npm install -g n
sudo n stable