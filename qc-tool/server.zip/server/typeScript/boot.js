function printLabel(labeledObj) {
    console.log(labeledObj.label);
}
var myObj;
myObj = {
    label: "this is label"
};
printLabel(myObj);
