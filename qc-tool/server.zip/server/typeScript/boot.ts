interface Named {
    name: string;
}
